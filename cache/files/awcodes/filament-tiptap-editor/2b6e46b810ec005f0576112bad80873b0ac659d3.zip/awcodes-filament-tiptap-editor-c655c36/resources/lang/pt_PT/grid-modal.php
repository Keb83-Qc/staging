<?php

return [
    'heading' => 'Construtor de Grade',
    'labels' => [
        'submit' => 'Inserir Grade',
        'columns' => 'Colunas',
        'stack_at' => 'Empilhar em',
        'asymmetric' => 'Assimétrico',
        'asymmetric_left' => 'Largura da coluna esquerda',
        'asymmetric_right' => 'Largura da coluna direita',
        'dont_stack' => 'Não Empilhar',
    ],
];
