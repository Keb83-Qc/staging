<?php

return [
    'heading' => 'Editează codul sursă',
    'buttons' => [
        'cancel' => 'Anulează',
        'update' => 'Actualizează',
    ],
    'labels' => [
        'source' => 'Sursă',
    ],
];
