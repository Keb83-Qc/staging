<?php

return [
    'heading' => 'گرید بندی',
    'labels' => [
        'submit' => 'درج گرید',
        'columns' => 'ستون ها',
        'stack_at' => 'تغییر حالت در',
        'asymmetric' => 'نامتقارن',
        'asymmetric_left' => 'فاصله ستون چپ',
        'asymmetric_right' => 'فاصله ستون راست',
        'dont_stack' => 'بدون تغییر حالت',
    ],
];
