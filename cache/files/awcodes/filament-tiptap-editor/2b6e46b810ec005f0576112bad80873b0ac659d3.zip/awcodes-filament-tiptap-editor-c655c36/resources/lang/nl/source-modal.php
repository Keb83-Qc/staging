<?php

return [
    'heading' => 'Broncode bewerken',
    'buttons' => [
        'cancel' => 'Annuleren',
        'update' => 'Bijwerken',
    ],
    'labels' => [
        'source' => 'Bron',
    ],
];
