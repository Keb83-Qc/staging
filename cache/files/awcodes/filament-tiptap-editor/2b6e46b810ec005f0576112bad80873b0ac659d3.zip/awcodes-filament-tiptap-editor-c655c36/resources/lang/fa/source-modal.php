<?php

return [
    'heading' => 'ویرایش کد سورس',
    'buttons' => [
        'cancel' => 'لغو',
        'update' => 'به روز رسانی',
    ],
    'labels' => [
        'source' => 'سورس',
    ],
];
