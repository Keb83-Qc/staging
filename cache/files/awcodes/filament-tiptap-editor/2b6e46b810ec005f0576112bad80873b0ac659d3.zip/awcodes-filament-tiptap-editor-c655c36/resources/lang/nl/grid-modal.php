<?php

return [
    'heading' => 'Rasterbouwer',
    'labels' => [
        'submit' => 'Raster invoegen',
        'columns' => 'Kolommen',
        'stack_at' => 'Stapelen op',
        'asymmetric' => 'Asymmetrisch',
        'asymmetric_left' => 'Overspanning linkerkolom',
        'asymmetric_right' => 'Overspanning rechterkolom',
        'dont_stack' => 'Niet stapelen',
    ],
];
