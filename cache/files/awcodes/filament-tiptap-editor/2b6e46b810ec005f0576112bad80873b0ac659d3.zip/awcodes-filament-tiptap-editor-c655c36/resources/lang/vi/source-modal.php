<?php

return [
    'heading' => 'Chỉnh sửa mã nguồn',
    'buttons' => [
        'cancel' => 'Hủy',
        'update' => 'Cập nhật',
    ],
    'labels' => [
        'source' => 'Nguồn',
    ],
];
