<?php

return [
    'heading' => 'Izgara Oluşturucu',
    'labels' => [
        'submit' => 'Izgarayı Ekle',
        'columns' => 'Sütunlar',
        'stack_at' => 'Yığılmak Yer',
        'asymmetric' => 'Asimetrik',
        'asymmetric_left' => 'Sol Sütun Genişliği',
        'asymmetric_right' => 'Sağ Sütun Genişliği',
        'dont_stack' => 'Yığılma Yapma',
    ],
];
