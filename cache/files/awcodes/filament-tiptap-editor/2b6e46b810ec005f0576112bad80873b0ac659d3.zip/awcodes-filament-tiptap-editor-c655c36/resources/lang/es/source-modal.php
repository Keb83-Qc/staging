<?php

return [
    'heading' => 'Editar Código Fuente',
    'buttons' => [
        'cancel' => 'Cancelar',
        'update' => 'Actualizar',
    ],
    'labels' => [
        'source' => 'Fuente',
    ],
];
