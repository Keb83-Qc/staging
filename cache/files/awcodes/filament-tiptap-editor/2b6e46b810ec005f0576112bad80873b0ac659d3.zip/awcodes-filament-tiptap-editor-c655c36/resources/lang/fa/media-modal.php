<?php

return [
    'heading' => [
        'update' => 'به روز رسانی رسانه',
        'insert' => 'درج رسانه',
    ],
    'buttons' => [
        'cancel' => 'لغو',
        'insert' => 'درج',
    ],
    'labels' => [
        'file' => 'فایل',
        'link_text' => 'متن لینک',
        'alt' => 'متن جایگزین',
        'alt_helper_text' => 'یاد بگیرید که چگونه هدف تصویر را توصیف کنید.',
        'title' => 'عنوان',
        'lazy' => 'لیزی لود',
    ],
];
