<?php

return [
    'heading' => 'Construtor de Grade',
    'labels' => [
        'submit' => 'Inserir Grade',
        'columns' => 'Colunas',
        'stack_at' => 'Empilhar em',
        'asymmetric' => 'Assimétrico',
        'asymmetric_left' => 'Extensão da Coluna Esquerda',
        'asymmetric_right' => 'Extensão da Coluna Direita',
        'dont_stack' => 'Não Empilhar',
    ],
];
