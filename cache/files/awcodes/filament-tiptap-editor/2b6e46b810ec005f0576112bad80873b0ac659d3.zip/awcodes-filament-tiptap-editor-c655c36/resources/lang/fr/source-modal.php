<?php

return [
    'heading' => 'Modifier le code source',
    'buttons' => [
        'cancel' => 'Annuler',
        'update' => 'Mettre à jour',
    ],
    'labels' => [
        'source' => 'Source',
    ],
];
