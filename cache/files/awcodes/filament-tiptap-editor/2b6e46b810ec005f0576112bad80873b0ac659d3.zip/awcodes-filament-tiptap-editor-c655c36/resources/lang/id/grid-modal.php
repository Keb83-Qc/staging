<?php

return [
    'heading' => 'Pembangun Grid',
    'labels' => [
        'submit' => 'Sisipkan Grid',
        'columns' => 'Kolom',
        'stack_at' => 'Tumpuk Pada',
        'asymmetric' => 'Asimetris',
        'asymmetric_left' => 'Rentang Kolom Kiri',
        'asymmetric_right' => 'Rentang Kolom Kanan',
        'dont_stack' => 'Jangan Tumpuk',
    ],
];
