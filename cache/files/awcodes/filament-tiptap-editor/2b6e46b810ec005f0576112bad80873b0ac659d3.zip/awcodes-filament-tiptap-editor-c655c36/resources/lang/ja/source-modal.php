<?php

return [
    'heading' => 'ソースコードを編集',
    'buttons' => [
        'cancel' => 'キャンセル',
        'update' => '更新',
    ],
    'labels' => [
        'source' => 'ソース',
    ],
];
