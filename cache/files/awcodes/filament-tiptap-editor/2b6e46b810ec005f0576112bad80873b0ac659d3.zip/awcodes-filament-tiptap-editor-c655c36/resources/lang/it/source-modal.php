<?php

return [
    'heading' => 'Modifica Codice Sorgente',
    'buttons' => [
        'cancel' => 'Annulla',
        'update' => 'Aggiorna',
    ],
    'labels' => [
        'source' => 'Sorgente',
    ],

];
