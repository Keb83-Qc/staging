<?php

return [
    'heading' => 'Kolumner',
    'labels' => [
        'submit' => 'Infoga kolumner',
        'columns' => 'Kolumner',
        'stack_at' => 'Stapla vid',
        'asymmetric' => 'Asymmetrisk',
        'asymmetric_left' => 'Vänster kolumnspann',
        'asymmetric_right' => 'Höger kolumnspann',
        'dont_stack' => 'Stapla inte',
    ],
];
