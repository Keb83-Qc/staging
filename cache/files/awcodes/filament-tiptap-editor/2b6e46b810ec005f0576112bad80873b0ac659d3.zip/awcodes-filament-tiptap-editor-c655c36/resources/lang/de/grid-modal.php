<?php

return [
    'heading' => 'Grid-Builder',
    'labels' => [
        'submit' => 'Grid einfügen',
        'columns' => 'Spalten',
        'stack_at' => 'Umbruch bei',
        'asymmetric' => 'Asymmetrisch',
        'asymmetric_left' => 'Linke Spaltenbreite',
        'asymmetric_right' => 'Rechte Spaltenbreite',
        'dont_stack' => 'Nicht umbrechen',
    ],
];
