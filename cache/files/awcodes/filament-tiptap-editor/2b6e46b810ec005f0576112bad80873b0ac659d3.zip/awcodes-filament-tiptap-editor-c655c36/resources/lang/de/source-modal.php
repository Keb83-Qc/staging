<?php

return [
    'heading' => 'Quellcode bearbeiten',
    'buttons' => [
        'cancel' => 'Abbrechen',
        'update' => 'Aktualisieren',
    ],
    'labels' => [
        'source' => 'Quelle',
    ],
];
