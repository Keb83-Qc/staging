<?php

return [
    'heading' => '그리드 빌더',
    'labels' => [
        'submit' => '그리드 삽입',
        'columns' => '열',
        'stack_at' => 'Stack At',
        'asymmetric' => '비대칭',
        'asymmetric_left' => '왼쪽 열 범위',
        'asymmetric_right' => '오른쪽 열 범위',
        'dont_stack' => '스택하지 않음',
    ],
];
