<?php

return [
    'heading' => 'グリッドビルダー',
    'labels' => [
        'submit' => 'グリッドを挿入',
        'columns' => 'カラム',
        'stack_at' => 'スタック位置',
        'asymmetric' => '非対称',
        'asymmetric_left' => '左カラムのスパン',
        'asymmetric_right' => '右カラムのスパン',
        'dont_stack' => 'スタックしない',
    ],
];
