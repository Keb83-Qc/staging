<?php

return [
    'heading' => 'تحرير كود المصدر',
    'buttons' => [
        'cancel' => 'إلغاء',
        'update' => 'تحديث',
    ],
    'labels' => [
        'source' => 'المصدر',
    ],
];
