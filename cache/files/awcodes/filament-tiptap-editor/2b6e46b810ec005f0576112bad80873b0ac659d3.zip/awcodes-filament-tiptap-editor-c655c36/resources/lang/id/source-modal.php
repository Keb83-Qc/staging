<?php

return [
    'heading' => 'Edit Kode Sumber',
    'buttons' => [
        'cancel' => 'Batal',
        'update' => 'Perbarui',
    ],
    'labels' => [
        'source' => 'Kode Sumber',
    ],
];
