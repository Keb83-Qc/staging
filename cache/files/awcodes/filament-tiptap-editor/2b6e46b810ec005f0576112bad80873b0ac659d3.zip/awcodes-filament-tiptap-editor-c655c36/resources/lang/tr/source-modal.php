<?php

return [
    'heading' => 'Kaynak Kodunu Düzenle',
    'buttons' => [
        'cancel' => 'İptal',
        'update' => 'Güncelle',
    ],
    'labels' => [
        'source' => 'Kaynak',
    ],
];
