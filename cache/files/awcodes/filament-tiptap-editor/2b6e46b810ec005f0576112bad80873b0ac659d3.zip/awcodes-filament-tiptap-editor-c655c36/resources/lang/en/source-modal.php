<?php

return [
    'heading' => 'Edit Source Code',
    'buttons' => [
        'cancel' => 'Cancel',
        'update' => 'Update',
    ],
    'labels' => [
        'source' => 'Source',
    ],
];
