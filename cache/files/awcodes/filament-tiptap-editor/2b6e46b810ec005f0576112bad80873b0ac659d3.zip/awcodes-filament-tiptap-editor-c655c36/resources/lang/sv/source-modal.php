<?php

return [
    'heading' => 'Redigera källkod',
    'buttons' => [
        'cancel' => 'Avbryt',
        'update' => 'Uppdatera',
    ],
    'labels' => [
        'source' => 'Källkod',
    ],
];
