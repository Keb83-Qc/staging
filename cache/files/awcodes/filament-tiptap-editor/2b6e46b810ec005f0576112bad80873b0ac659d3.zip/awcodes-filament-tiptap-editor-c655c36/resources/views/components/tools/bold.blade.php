<x-filament-tiptap-editor::button
    action="editor().chain().focus().toggleBold().run()"
    active="bold"
    label="{{ trans('filament-tiptap-editor::editor.bold') }}"
    icon="bold"
/>