<x-filament-tiptap-editor::button
    action="editor().chain().focus().toggleSmall().run()"
    active="small"
    label="{{ trans('filament-tiptap-editor::editor.small') }}"
    icon="small"
/>
