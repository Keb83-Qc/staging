<x-filament-tiptap-editor::button
    action="editor().chain().focus().toggleItalic().run()"
    active="italic"
    label="{{ trans('filament-tiptap-editor::editor.italic') }}"
    icon="italic"
/>