<x-filament-tiptap-editor::button
    action="editor().chain().focus().toggleStrike().run()"
    active="strike"
    label="{{ trans('filament-tiptap-editor::editor.strike') }}"
    icon="strike"
/>
