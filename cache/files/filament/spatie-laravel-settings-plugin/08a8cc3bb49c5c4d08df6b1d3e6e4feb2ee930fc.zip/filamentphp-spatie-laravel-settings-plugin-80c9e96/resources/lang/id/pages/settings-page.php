<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Simpan',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Pengaturan berhasil disimpan',
        ],

    ],

];
