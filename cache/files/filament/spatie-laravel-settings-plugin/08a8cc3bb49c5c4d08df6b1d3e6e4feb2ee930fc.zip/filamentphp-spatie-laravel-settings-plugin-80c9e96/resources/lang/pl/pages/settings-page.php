<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Zapisz',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Zapisano zmiany',
        ],

    ],

];
