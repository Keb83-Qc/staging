<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'সংরক্ষণ করুন',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'সংরক্ষিত হয়েছে',
        ],

    ],

];
