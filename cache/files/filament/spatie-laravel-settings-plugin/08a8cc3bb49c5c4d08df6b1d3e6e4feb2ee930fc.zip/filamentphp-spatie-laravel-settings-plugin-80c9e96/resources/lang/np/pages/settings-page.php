<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'परिवर्तनहरू सुरक्षित गर्नुहोस',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'सुरक्षित गरियो',
        ],

    ],

];
