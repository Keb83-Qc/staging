<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => '保存',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => '已保存',
        ],

    ],

];
