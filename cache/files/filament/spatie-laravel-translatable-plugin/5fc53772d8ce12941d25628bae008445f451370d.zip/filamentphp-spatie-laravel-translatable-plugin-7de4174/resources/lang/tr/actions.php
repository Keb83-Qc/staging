<?php

return [

    'active_locale' => [
        'label' => 'Yerel ayar',
    ],

];
