<?php

return [

    'active_locale' => [
        'label' => 'स्थानीय भाषा',
    ],

];
