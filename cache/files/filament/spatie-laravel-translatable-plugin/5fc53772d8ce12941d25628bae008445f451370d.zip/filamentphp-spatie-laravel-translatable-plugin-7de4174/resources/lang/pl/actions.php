<?php

return [

    'active_locale' => [
        'label' => 'Aktywny język',
    ],

];
