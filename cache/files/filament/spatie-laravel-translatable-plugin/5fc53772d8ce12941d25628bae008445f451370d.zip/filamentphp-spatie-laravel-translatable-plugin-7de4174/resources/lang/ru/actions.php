<?php

return [

    'active_locale' => [
        'label' => 'Язык',
    ],

];
