<?php

return [

    'active_locale' => [
        'label' => '語系',
    ],

];
