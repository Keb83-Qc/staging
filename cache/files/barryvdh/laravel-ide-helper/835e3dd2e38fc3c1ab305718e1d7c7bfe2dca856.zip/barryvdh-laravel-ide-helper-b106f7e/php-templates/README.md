The templates here are based on the official VS Code extension by Laravel https://github.com/laravel/vs-code-extension

Modifications:
 - return instead of echo
 - do not serialize to JSON
