<?php

namespace Livewire\Attributes;

use Livewire\Features\SupportReactiveProps\BaseReactive;

#[\Attribute]
class Reactive extends BaseReactive
{
    //
}
