<?php

namespace Livewire\Attributes;

use Livewire\Features\SupportLazyLoading\BaseLazy;

#[\Attribute]
class Lazy extends BaseLazy
{
    //
}
