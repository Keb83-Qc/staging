<?php

return [
    'title' => 'Title',
    'description' => 'Description',
    'author' => 'Author name',
    'image' => 'Image',
    'characters' => 'Characters',
    'robots' => 'Meta Tag Robots',
];
