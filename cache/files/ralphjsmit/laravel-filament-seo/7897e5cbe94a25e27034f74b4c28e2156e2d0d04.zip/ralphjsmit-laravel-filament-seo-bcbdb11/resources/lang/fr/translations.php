<?php

return [
    'title' => 'Titre',
    'description' => 'Description',
    'author' => "Nom de l'auteur",
    'image' => 'Image',
    'characters' => 'Caractères',
    'robots' => 'Balise meta Robots',
];
