<?php

return [
    'title' => 'العنوان',
    'description' => 'الوصف',
    'author' => 'اسم المؤلف',
    'image' => 'صورة',
    'characters' => 'الأحرف',
    'robots' => 'وسم ميتا Robots',
];
